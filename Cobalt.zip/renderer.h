#ifndef RENDERER_H_INCLUDED
#define RENDERER_H_INCLUDED

struct render_group{



}

#endif // RENDERER_H_INCLUDED
